
#include <stdlib.h>
#include <stdio.h>
#include "liste.h"

/*
 * definition de la fonction principale
 */

int main() {
	element_t x =  0.0;
	int i;
	liste_t suite_de_l = liste_vide();

	/* creation d'une liste vide */
	liste_t   l = liste_vide();

	/* affichage de la liste */
	puts("liste avant l'ajout des elements    : ");
	liste_afficher(l);
	putchar('\n');

	/* ajout de 5 elements a la liste */
	for(i = 1; i <= 5; ++i) {
		l = liste_ajout_a_la_fin(x + i / 5.0, l);
	}
	
	/* affichage de la liste */
	puts("liste apres l'ajout des elements     : ");
	liste_afficher(l);
	putchar('\n');
	
	/* recuperation de la suite de l */
	suite_de_l = liste_suite(l);
	
	/* affichage de la liste obtenue par un appel a suite */
	puts("suite de la liste                     : ");
	liste_afficher(suite_de_l);
	putchar('\n');
	
	/* destruction de la liste "suite_de_l" */
	liste_detruire(&suite_de_l);

	/* affichage de la liste "l" */
	puts("liste apres la destruction de la suite : ");
	liste_afficher(l);
	putchar('\n');
	
	/* destruction de la liste */
	liste_detruire(&l);

	return EXIT_SUCCESS;
}
