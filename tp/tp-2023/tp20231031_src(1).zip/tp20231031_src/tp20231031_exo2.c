#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "liste.h"

/*
 * declaration des constantes symboliques
 */
#ifndef NB
#define NB 8
#endif


/*
 * declaration de fonctions utilisateur
 */

liste_t generer_liste(int);


/*
 * definition de la fonction principale
 */

int main() {
	liste_t l = liste_vide();

	/* initialisation du generateur de nombres pseudo-aleatoires */
	srand(time(0));
	
	/* generation d'une liste aleatoire de NB elements */
	l = generer_liste(NB);
	
	/* affichage de la liste non triee */
	puts("liste non triee :");
	liste_afficher(l);
	putchar('\n');
	
	/* ordonner les elements suivant l'algorithme du tri fusion */
	liste_tri_fusion(&l);
	
	/* affichage de la liste triee */
	puts("liste triee     :");
	liste_afficher(l);
	putchar('\n');

	/* destruction de la liste */
	liste_detruire(&l);

	return EXIT_SUCCESS;
}


/*
 * definition de fonctions utilisateur
 */

liste_t generer_liste(int n) {
	liste_t lres = liste_vide();
	while (n-- > 0)
		lres = liste_ajout_au_debut(rand() / (1.0 + rand()), lres);
	return lres;
}
