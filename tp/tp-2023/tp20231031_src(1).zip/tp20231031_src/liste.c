#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "liste.h"

/*
 * declaration du modele de structure maillon_s
 */
struct maillon_s {
	element_t valeur;
	maillon_t suivant;
};


/*
 * declarations des fonctions de manipulation des maillons
 *
 * remarque 1 : ces fonctions sont declarees "static" car elles ne
 *              doivent pas etre appelees en dehors de ce fichier
 *
 * remarque 2 : aucun acces aux valeurs des champs d'un maillon, en dehors
 *              des 6 fonctions dont le nom est prefixe par "maillon_", ne
 *              doit se faire directement, c'est-a-dire sans passer par une
 *              de ces 6 fonctions
 */
static maillon_t maillon_creer(element_t, maillon_t);
static void maillon_detruire(maillon_t *);
static element_t maillon_get_valeur(maillon_t);
static maillon_t maillon_get_suivant(maillon_t);
static void maillon_set_valeur(maillon_t *, element_t);
static void maillon_set_suivant(maillon_t *, maillon_t);


/*=============================================================================*
 *                         definitions des fonctions de manipulation des listes
 *=============================================================================*/

liste_t liste_vide() {
	liste_t res;
	
	res.premier = NULL;
	res.dernier = NULL;
	
	return res;
}


liste_t liste_ajout_au_debut(element_t x, liste_t l) {
	l.premier = maillon_creer(x, l.premier);
	
	if (NULL == l.dernier) {
		l.dernier = l.premier;
	}
	
	return l;
}


liste_t liste_ajout_a_la_fin(element_t x, liste_t l) {
	if(NULL == l.dernier) {
		return liste_ajout_au_debut(x, l);
	}
	
	maillon_set_suivant(&(l.dernier), maillon_creer(x, NULL));
	l.dernier = maillon_get_suivant(l.dernier);
	
	return l;
}


void liste_detruire(liste_t * pl) {
	assert(NULL != pl);
	
	while (NULL != pl->premier) {
		pl->dernier = pl->premier;
		pl->premier = maillon_get_suivant(pl->premier);
		maillon_detruire(&(pl->dernier));
	}
}


element_t liste_premier(liste_t l) {
	assert(NULL != l.premier);

	return maillon_get_valeur(l.premier);
}


liste_t liste_suite(liste_t l) {
	liste_t res;
	
	assert(NULL != l.premier);
	
	res.premier = maillon_get_suivant(l.premier);
	if (NULL == res.premier) {
		res.dernier = NULL;
	}
	else {
		res.dernier = l.dernier;
	}
	
	return res;
}


int liste_est_vide(liste_t l) {
	return NULL == l.premier;
}


void liste_afficher(liste_t l) {
	putchar('[');
	if (! liste_est_vide(l)) {
		putchar(' ');
		element_afficher(liste_premier(l));
		l = liste_suite(l);
		while (!liste_est_vide(l)) {
			putchar(',');
			putchar(' ');
			element_afficher(liste_premier(l));
			l = liste_suite(l);
		}
		putchar(' ');
	}
	putchar(']');
}


void liste_concatener(liste_t * plres, liste_t * pl) {
	assert(NULL != plres);
	assert(NULL != pl);

	if (NULL != pl->premier) {
		plres->dernier->suivant = pl->premier;
		plres->dernier          = pl->dernier;
		pl->premier = NULL;
		pl->dernier = NULL;
	}
}


/*=============================================================================*
 *                                                 implementation du tri fusion
 *=============================================================================*/

/*
 * declarations des fonctions auxiliaires utilisees pour le tri fusion
 *
 * remarque : ces fonctions sont declarees "static" car elles ne
 *            doivent pas etre appelees en dehors de ce fichier
 */

/*=============================================================================
 *                                                 liste_concatener
 * Cette fonction concatene les deux listes dont elle recoit les adresses
 * en arguments.
 *
 *  pre-condition(s) : - les elements des listes (*pl1) et (*pl2) sont
 *                       ordonnes de facon croissante
 * post-condition(s) : - les listes (*pl1) et (*pl2) sont vides apres
 *                       l'execution de la fonction
 *                     - la liste (*plres) contient les elements qui etaient
 *                       initialement dans les listes (*pl1) et (*pl2)
 *                     - les elements de la liste (*plres) sont ordonnes
 *                       de facon croissante
 */
static void liste_fusionner(liste_t * pl1, liste_t * pl2, liste_t * plres);

/*=============================================================================
 *                                                 liste_scinder
 * Cette fonction distribue equitablement les elements
 * de la liste (*pl) aux listes (*pl1) et (*pl2).
 *
 *  pre-condition(s) : (pl != NULL) && (pl1 != NULL) && (pl2 != NULL)
 * post-condition(s) : - la liste (*pl) est vide apres l'execution de la
 *                       fonction
 *                     - les listes (*pl1) et (*pl2) ont "gagne" chacune
 *                       le meme nombre de jetons a une unite pres
 */
static void liste_scinder(liste_t * pl, liste_t * pl1, liste_t * pl2);


/*=============================================================================
 *                                                 liste_scinder
 * Cette fonction extrait le premier maillon de la liste (*pl).
 *
 *  pre-condition(s) : la liste n'est pas vide
 * post-condition(s) : - la liste (*pl) contient un element de moins
 *                     - le maillon renvoye pointe vers NULL ; il n'a pas
 *                       de successeur
 */
static maillon_t liste_extraire_premier(liste_t * pl);

/*=============================================================================
 *                                                 liste_inserer_en_fin
 * Cette fonction insere le maillon (m) a la fin de la liste (*pl).
 *
 *  pre-condition(s) : - (pl != NULL)
 *                     - la liste (*pl) n'est pas vide
 * post-condition(s) : - la liste (*pl) contient un element de moins
 *                     - le maillon renvoye pointe vers NULL ; il n'a pas
 *                       de successeur
 */
void liste_inserer_en_fin(liste_t * pl, maillon_t m);


/*
 * definitions des fonctions utilisees pour le tri fusion
 */

void liste_tri_fusion(liste_t * pl) {
	assert(NULL != pl);

	puts("COMPLETER LES FONCTIONS CI-DESSOUS AVANT D'UTILISER LA FONCTION liste_tri_fusion !");
	return;
	
	if (pl->premier != pl->dernier) {
		/* *pl est une liste d'au moins 2 elements */
		liste_t l1 = liste_vide(), l2 = liste_vide();

		liste_scinder(pl, &l1, &l2);

		liste_tri_fusion(&l1);
		liste_tri_fusion(&l2);

		liste_fusionner(&l1, &l2, pl);
	}
}


void liste_fusionner(liste_t * pl1, liste_t * pl2, liste_t * plres) {
	assert(NULL != pl1);
	assert(NULL != pl2);
	assert(NULL != plres);
	
	while( !liste_est_vide(*pl1) && !liste_est_vide(*pl2) ) {
		maillon_t m = NULL;
		if (-1 == element_comparer(liste_premier(*pl1), liste_premier(*pl2))) {
			m = liste_extraire_premier(pl1);
		}
		else {
			m = liste_extraire_premier(pl2);
		}
		if (NULL == plres->premier) {
			plres->premier = m;
		}
		else {
			liste_inserer_en_fin(plres, m);
		}
		plres->dernier = m;
	}
	liste_concatener(plres, pl1);
	liste_concatener(plres, pl2);
}


void liste_scinder(liste_t * pl, liste_t * pl1, liste_t * pl2) {
	assert(NULL != pl);
	assert(NULL != pl1);
	assert(NULL != pl2);

	if( !liste_est_vide(*pl) ) {
		maillon_t m = liste_extraire_premier(pl);
		if (NULL == pl1->premier) {
			/* <------------------------------<< A COMPLETER par 2 affectations */
		}
		else {
			liste_inserer_en_fin(pl1, m);
		}
		liste_scinder(pl, pl2, pl1);
	}
}


maillon_t liste_extraire_premier(liste_t * pl) {
	maillon_t m = NULL;

	assert(NULL != pl);
	assert(NULL != pl->premier);
	
	/* <------------------------------<< A COMPLETER par 3 affectations */

	return m;
}


void liste_inserer_en_fin(liste_t * pl, maillon_t m) {
	assert(NULL != pl);
	assert(NULL != m);
	assert(NULL == m->suivant);

	if (NULL == pl->premier) {
		/* <------------------------------<< A COMPLETER par 1 affectation */
	}
	else {
		/* <------------------------------<< A COMPLETER par 1 affectation */
	}
	pl->dernier = m;
}

/*=============================================================================*
 *                       definitions des fonctions de manipulation des maillons
 *=============================================================================*/

maillon_t maillon_creer(element_t x, maillon_t suiv) {
	maillon_t res = (maillon_t) malloc(sizeof(struct maillon_s));
	
	if (NULL == res) {
		perror("maillon_creer : echec de l'allocation de memoire");
		exit(-1);
	}
	
	res->valeur  = x;
	res->suivant = suiv;
	
	return res;
}


void maillon_detruire(maillon_t * pm) {
	assert(NULL != pm);
	assert(NULL != *pm);

	free(*pm);
	*pm = NULL;
}


element_t maillon_get_valeur(maillon_t m) {
	assert(NULL != m);
	
	return m->valeur;
}


maillon_t maillon_get_suivant(maillon_t m) {
	assert(NULL != m);
	
	return m->suivant;
}


void maillon_set_valeur(maillon_t * pm, element_t x) {
	assert(NULL != pm);
	assert(NULL != *pm);
	
	(*pm)->valeur = x;
}


void maillon_set_suivant(maillon_t * pm, maillon_t m) {
	assert(NULL != pm);
	assert(NULL != *pm);
	
	(*pm)->suivant = m;
}
