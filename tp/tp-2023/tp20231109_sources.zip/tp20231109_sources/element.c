/*ZABAR Aïmane (Groupe 1) 
GBADAMASSI Inès (Groupe 1)*/



#include <stdio.h>
#include "element.h"


void element_afficher(element_t x) {
	printf("%.2f", x);
}


int element_comparer(element_t x, element_t y) {
	return (x == y) ? 0 : ((x < y) ? (-1) : 1);
}
