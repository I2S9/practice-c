/*ZABAR Aïmane (Groupe 1) 
GBADAMASSI Inès (Groupe 1)*/



#ifndef __LISTE_H__
#define __LISTE_H__

#include "element.h"

/*
 * declarations des types
 */
typedef struct maillon_s * maillon_t;
typedef struct liste_s     liste_t;

/*
 * déclarations des modeles de structures
 */
struct liste_s {
	maillon_t premier;
	maillon_t dernier;
};


/*=============================================================================
 *                                                 liste_vide
 * Cette fonction renvoie une liste vide.
 *
 *  pre-condition(s) : aucune
 * post-condition(s) : la liste renvoyée ne contient aucun element
 */
liste_t liste_vide();

/*=============================================================================
 *                                                 liste_ajout_au_debut
 * Cette fonction ajoute un element au debut d'une liste.
 *
 *  pre-condition(s) : aucune
 * post-condition(s) : - l'element recu en argument a ete ajoute au debut
 *                       de la liste recue en argument
 */
liste_t liste_ajout_au_debut(element_t, liste_t);

/*=============================================================================
 *                                                 liste_ajout_a_la_fin
 * Cette fonction ajoute un element a la fin d'une liste.
 *
 *  pre-condition(s) : aucune
 * post-condition(s) : - l'element recu en argument a ete ajoute a la fin
 *                       de la liste recue en argument
 */
liste_t liste_ajout_a_la_fin(element_t, liste_t);

/*=============================================================================
 *                                                 liste_detruire
 * Cette fonction detruit les elements de la liste dont elle recoit
 * l'adresse en argument.
 *
 *  pre-condition(s) : - l'adresse recue n'est pas NULL
 *                     - les elements de la liste ne doivent pas etre partages
 *                       avec une autre liste
 * post-condition(s) : la liste est vide
 */
void liste_detruire(liste_t *);

/*=============================================================================
 *                                                 liste_premier
 * Cette fonction renvoie le premier element de la liste qu'elle recoit en
 * argument est vide.
 *
 *  pre-condition(s) : la liste n'est pas vide
 * post-condition(s) : la liste renvoyée ne contient aucun element
 */
element_t liste_premier(liste_t);

/*=============================================================================
 *                                                 liste_suite
 * Cette fonction renvoie la suite d'une liste, c'est-a-dire la liste privee
 * de son premier element ; .
 *
 *  pre-condition(s) : la liste n'est pas vide
 * post-condition(s) : - la liste recue en argument n'est pas modifiee
 *                     - les elements de la liste renvoyee sont partages avec
 *                       avec la liste recue
 */
liste_t liste_suite(liste_t);

/*=============================================================================
 *                                                 liste_est_vide
 * Cette fonction renvoie une valeur non nulle si la liste qu'elle recoit en
 * argument est vide et zéro dans le cas contraire.
 *
 *  pre-condition(s) : aucune
 * post-condition(s) : la liste renvoyée ne contient aucun element
 */
int liste_est_vide(liste_t);

/*=============================================================================
 *                                                 liste_afficher
 * Cette fonction affiche le contenu d'une liste entre crochets en
 * separant les elements consecutifs par une virgule ; le dernier
 * caractère affiche est un crochet fermant.
 *
 *  pre-condition(s) : aucune
 * post-condition(s) : la liste recue en argument est affichee
 */
void liste_afficher(liste_t);

/*=============================================================================
 *                                                 liste_concatener
 * Cette fonction concatene les deux listes dont elle recoit les adresses
 * en arguments.
 *
 *  pre-condition(s) : - les adresses recues ne sont pas NULL
 * post-condition(s) : - la liste dont l'adresse est recue en 2eme argument
 *                       est vide apres l'execution de la fonction ; tous ses
 *                       elements ont ete ajoutes a la fin de la liste dont
 *                       l'adresse est recue en 1er argument.
 */
void liste_concatener(liste_t *, liste_t *);

/*=============================================================================
 *                                                 liste_tri_fusion
 * Cette fonction ordonne de facon croissante les elements de la liste
 * dont elle recoit l'adresse en argument ; la fonction l'algorithme
 * du tri fusion.
 *
 *  pre-condition(s) : - les adresses recues ne sont pas NULL
 * post-condition(s) : - les elements de la liste dont l'adresse est recue
 *                       argument sont ordonnes de facon croissante apres
 *                       l'execution de la fonction
 */
int liste_tri_fusion(liste_t *);
void liste_tri_a_bulle(liste_t *);

#endif


