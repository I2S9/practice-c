/*ZABAR Aïmane (Groupe 1) 
GBADAMASSI Inès (Groupe 1)*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "liste.h"

/*
 * declaration des constantes symboliques
 */
#ifndef NB
#define NB 8
#endif


/*
 * declaration de fonctions utilisateur
 */

liste_t generer_liste(int);


/*
 * definition de la fonction principale
 */

int main() {

    int t[1024];
    int essai,j,k,s;

    srand((12201275+12200874)%1000);
    for( k=1; k<10; k++){
        for(essai=1; essai<100; essai++){
            for(s=0 ; s<1024; s++){
                t[s]= rand();
            }
            liste_t l1 = liste_vide();
            liste_t l2 = liste_vide();
            for(j =0; j< (1<<k); j++){
                l1 = liste_ajout_au_debut(t[j], l1);
                l2 = liste_ajout_au_debut(t[j], l2);
            }
            printf("%d,%d,%d,%d\n", 1<<k , essai, liste_tri_bulle(&l1),  liste_tri_fusion(&l2));
            liste_detruire(&l1);
            liste_detruire(&l2);
        }
    }
}


/*
 * definition de fonctions utilisateur
 */

liste_t generer_liste(int n) {
	liste_t lres = liste_vide();
	while (n-- > 0)
		lres = liste_ajout_au_debut(rand() / (1.0 + rand()), lres);
	return lres;
}
