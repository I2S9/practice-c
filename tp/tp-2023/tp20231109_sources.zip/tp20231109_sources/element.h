/*ZABAR Aïmane (Groupe 1) 
GBADAMASSI Inès (Groupe 1)*/



#ifndef __ELEMENT_H__
#define __ELEMENT_H__

/*
 * declarations d'un type synonyme
 */
typedef double element_t;

/*=============================================================================
 *                                                 element_afficher
 * Cette fonction affiche un element.
 *
 *  pre-condition(s) : aucune
 * post-condition(s) : l'element est affiche sur la sortie standard
 */
void element_afficher(element_t);

/*=============================================================================
 *                                                 element_comparer
 * Cette fonction compare deux elements x et y ; elle renvoie
 *  . (-1)  si x < y
 *  .   0   si x = y
 *  .   1   si x > y
 *
 *  pre-condition(s) : aucune
 * post-condition(s) : aucune
 */
int  element_comparer(element_t x, element_t y);

#endif
